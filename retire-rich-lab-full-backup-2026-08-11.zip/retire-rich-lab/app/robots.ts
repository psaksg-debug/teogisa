import type { MetadataRoute } from "next";
import { SITE_URL } from "../lib/site";
export default function robots():MetadataRoute.Robots{return{rules:[{userAgent:"*",allow:"/",disallow:["/admin","/api/","/search?"]},{userAgent:["GPTBot","ChatGPT-User","PerplexityBot","ClaudeBot","Google-Extended"],allow:"/",disallow:["/admin","/api/"]}],sitemap:`${SITE_URL}/sitemap.xml`,host:SITE_URL};}
