# 퇴.기.사 decisions carried from the originating conversation

- Team mission: check posting quality after publication and verify the live result.
- Primary audience goal: intuitive reading, comfortable scanning, and strong readability for middle-aged and older readers.
- Increase the visual balance of the logo, site title, tagline, navigation, and mobile menu text.
- Enlarged article text must wrap without clipping the viewport.
- Search-result metadata, title, and summary must not run together. Result rows need visible separation.
- Remove the phrases and modules `읽은 뒤 다시 확인`, `핵심 내용과 확인표`, `읽으면서 확인할 표`, generic four-step flows, and generic confirmation tables.
- Keep genuine lists visible and intentionally styled; do not rely only on prose and tables.
- Keep organization charts and internal operating guidance off the public website.
- Add official and helpful outbound links to relevant text and open them safely in a new tab.
- Maintain outbound links twice daily when scheduling is authorized.
- Add a home `최근 발행 글` section showing five title rows and one category per row.
- Order the latest section and every other public posting list newest first.
- A local build is not a release. After explicit approval, deploy and inspect the real public URL.
