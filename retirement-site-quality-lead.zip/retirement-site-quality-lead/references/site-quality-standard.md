# Site quality standard

## Reader experience

- Keep Korean body copy near 18–19 px on phones and 19 px on desktop, with roughly 1.75–1.9 line height.
- Keep reading measure around 40–45 Korean characters where the layout permits.
- Allow headings, paragraphs, links, list items, table cells, and labels to wrap at increased reader font sizes.
- Prevent horizontal page overflow at 375 px. Give flex/grid children `min-width: 0` and use `overflow-wrap: anywhere` only where long tokens require it.
- Tables must remain readable without clipping. Prefer fixed layout and wrapping when reader text is enlarged; use contained horizontal scrolling only when the data cannot reflow.

## Navigation and identity

- Make the site name and tagline legible at a glance.
- Keep primary desktop navigation around 14–16 px and mobile menu targets at least 44 px high.
- Replace crowded desktop navigation with the mobile menu before labels collide.
- Verify the header at 375, 900, 1024, and 1440 px when navigation changes.

## Post lists

- Use one shared newest-first comparator for home, search, related-post, RSS, and other public lists.
- Compare the calendar date first because stored timestamps and bundled `YYYY-MM-DD` dates may use different formats.
- Break same-day ties with descending stable ID.
- Separate image, metadata, title, and excerpt into explicit grid regions.
- Add row gaps or card boundaries so neighboring thumbnails never appear merged.
- Clamp excerpts only when necessary; never clip titles.

## Article structure

- Use prose for explanation, lists for procedures/options, and tables for comparison.
- Style `ul` and `ol` markers clearly and maintain comfortable spacing between items.
- Remove reusable filler checklists that do not add topic-specific value.
- Preserve content-specific warnings, source notes, calculations, examples, and official links.
- Never expose internal team instructions, QA policies, organization charts, or agent rosters on public pages.

## External links

- Link the institution name itself when the surrounding paragraph refers to an official body.
- Prefer official domains and deep links that support the nearby claim.
- Use `target="_blank" rel="noopener noreferrer"` for external destinations.
- Avoid linking common words repeatedly. One contextual link per institution or task is usually enough.
- Check recent posts first, then older published posts. Record inaccessible links for review rather than deleting them automatically.

## Release gates

1. No merge markers or formatting errors.
2. Automated tests and production build pass.
3. Desktop and emulated-mobile rendering show no overlap or horizontal overflow.
4. Latest-post count, category labels, and order are confirmed from rendered HTML.
5. Newer remote work is integrated without force-pushing.
6. Production approval is explicit.
7. Deployment succeeds and the custom domain serves the expected version.
8. Recent article links and external-link attributes are checked on the public site.
