#!/usr/bin/env node

const baseUrl = new URL(process.argv[2] ?? "https://adbles.com");
const timeoutMs = Number(process.env.SITE_AUDIT_TIMEOUT_MS ?? 12000);
const forbiddenPhrases = ["읽은 뒤 다시 확인", "핵심 내용과 확인표", "읽으면서 확인할 표"];

function absolute(path) {
  return new URL(path, baseUrl).href;
}

async function request(url, options = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, {
      redirect: "follow",
      signal: controller.signal,
      ...options,
      headers: { "user-agent": "RetirementSiteQualityLead/1.0", ...(options.headers ?? {}) },
    });
  } finally {
    clearTimeout(timer);
  }
}

async function fetchHtml(path) {
  const url = absolute(path);
  const response = await request(url);
  const body = await response.text();
  return { url, status: response.status, body };
}

function decode(value) {
  return value
    .replaceAll("&amp;", "&")
    .replaceAll("&quot;", '"')
    .replaceAll("&#x27;", "'")
    .replaceAll("&lt;", "<")
    .replaceAll("&gt;", ">");
}

function recentPosts(html) {
  const list = html.match(/<ol class="recent-title-list">([\s\S]*?)<\/ol>/)?.[1] ?? "";
  return [...list.matchAll(/<a href="([^"]+)"[^>]*>[\s\S]*?recent-post-category">([^<]+)<[\s\S]*?<strong>([^<]+)<\/strong>/g)]
    .map((match) => ({ href: decode(match[1]), category: decode(match[2].trim()), title: decode(match[3].trim()) }));
}

function externalLinks(html) {
  return [...new Set([...html.matchAll(/<a\b[^>]*href="(https?:\/\/[^"#]+)"/g)].map((match) => decode(match[1])))]
    .filter((url) => new URL(url).host !== baseUrl.host);
}

const report = {
  checkedAt: new Date().toISOString(),
  baseUrl: baseUrl.href,
  pages: [],
  recentPosts: [],
  prohibitedContent: [],
  externalLinks: [],
  errors: [],
  warnings: [],
};

for (const path of ["/", "/search", "/robots.txt", "/rss.xml"]) {
  try {
    const page = await fetchHtml(path);
    report.pages.push({ url: page.url, status: page.status });
    if (page.status !== 200) report.errors.push(`${page.url} returned ${page.status}`);
    if (path === "/") report.recentPosts = recentPosts(page.body);
  } catch (error) {
    report.errors.push(`${absolute(path)} failed: ${error instanceof Error ? error.message : String(error)}`);
  }
}

if (report.recentPosts.length !== 5) {
  report.errors.push(`Expected 5 recent posts, found ${report.recentPosts.length}`);
}
if (report.recentPosts.some((post) => !post.category || !post.title)) {
  report.errors.push("A recent-post row is missing its category or title");
}

const articleBodies = [];
for (const post of report.recentPosts) {
  try {
    const article = await fetchHtml(post.href);
    if (article.status !== 200) report.errors.push(`${article.url} returned ${article.status}`);
    articleBodies.push(article.body);
    for (const phrase of forbiddenPhrases) {
      if (article.body.includes(phrase)) report.prohibitedContent.push({ url: article.url, phrase });
    }
  } catch (error) {
    report.errors.push(`${absolute(post.href)} failed: ${error instanceof Error ? error.message : String(error)}`);
  }
}

if (report.prohibitedContent.length > 0) {
  report.errors.push(`Found ${report.prohibitedContent.length} prohibited generic article module(s)`);
}

const linkChecks = await Promise.all(externalLinks(articleBodies.join("\n")).slice(0, 30).map(async (url) => {
  try {
    let response = await request(url, { method: "HEAD" });
    if ([400, 405].includes(response.status)) {
      response = await request(url, { method: "GET", headers: { range: "bytes=0-0" } });
      await response.body?.cancel();
    }
    return { url, status: response.status, failed: response.status >= 400 && ![401, 403, 429].includes(response.status) };
  } catch {
    return { url, status: null, failed: false };
  }
}));

for (const check of linkChecks) {
  report.externalLinks.push({ url: check.url, status: check.status });
  if (check.status === null) report.warnings.push(`${check.url} could not be checked automatically`);
  else if ([401, 403, 429].includes(check.status)) report.warnings.push(`${check.url} requires manual review (${check.status})`);
  else if (check.failed) report.errors.push(`${check.url} returned ${check.status}`);
}

console.log(JSON.stringify(report, null, 2));
process.exitCode = report.errors.length > 0 ? 1 : 0;
